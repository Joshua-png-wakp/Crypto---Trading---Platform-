const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();
const { open } = require('sqlite');
const sendgrid = require('@sendgrid/mail');

// Configure SendGrid API key via env: SENDGRID_API_KEY and FROM_EMAIL and ADMIN_EMAIL
if (process.env.SENDGRID_API_KEY) {
  sendgrid.setApiKey(process.env.SENDGRID_API_KEY);
}

const app = express();
const port = process.env.PORT || 4000;
app.use(cors());
app.use(bodyParser.json());

// Create/open sqlite DB
let db;
(async () => {
  db = await open({ filename: path.join(__dirname,'data.db'), driver: sqlite3.Database });
  await db.run(`
    CREATE TABLE IF NOT EXISTS onboarding (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      broker TEXT,
      amount TEXT NOT NULL,
      createdAt TEXT NOT NULL
    );
  `);
  await db.run(`
    CREATE TABLE IF NOT EXISTS contact (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL,
      message TEXT,
      createdAt TEXT NOT NULL
    );
  `);
})();

app.get('/', (req,res)=> res.json({status:'server running'}));

app.post('/api/onboard', async (req,res)=>{
  const { name, broker, amount, agree } = req.body;
  if (!name || !amount || !agree) return res.status(400).json({ error: 'Missing required fields' });
  const createdAt = new Date().toISOString();
  const result = await db.run('INSERT INTO onboarding (name,broker,amount,createdAt) VALUES (?,?,?,?)', [name, broker || null, amount, createdAt]);
  const id = result.lastID;
  // send email to admin if configured
  if (process.env.SENDGRID_API_KEY && process.env.ADMIN_EMAIL && process.env.FROM_EMAIL) {
    const msg = {
      to: process.env.ADMIN_EMAIL,
      from: process.env.FROM_EMAIL,
      subject: `New onboarding request #${id}`,
      text: `New onboarding request:\nName: ${name}\nBroker: ${broker || 'N/A'}\nAmount: ${amount}\nTime: ${createdAt}`
    };
    try { await sendgrid.send(msg); } catch(e){ console.error('SendGrid error',e); }
  }
  return res.json({ ok:true, id });
});

app.post('/api/contact', async (req,res)=>{
  const { name, email, message } = req.body;
  if (!name || !email) return res.status(400).json({ error: 'Missing required fields' });
  const createdAt = new Date().toISOString();
  const result = await db.run('INSERT INTO contact (name,email,message,createdAt) VALUES (?,?,?,?)', [name, email, message || null, createdAt]);
  const id = result.lastID;
  if (process.env.SENDGRID_API_KEY && process.env.ADMIN_EMAIL && process.env.FROM_EMAIL) {
    const msg = {
      to: process.env.ADMIN_EMAIL,
      from: process.env.FROM_EMAIL,
      subject: `New contact message #${id}`,
      text: `From: ${name} <${email}>\nMessage:\n${message||''}`
    };
    try { await sendgrid.send(msg); } catch(e){ console.error('SendGrid error',e); }
  }
  return res.json({ ok:true, id });
});

// Admin endpoint (demo - NO AUTH). For production, add auth.
app.get('/api/admin/requests', async (req,res)=>{
  const onboard = await db.all('SELECT * FROM onboarding ORDER BY id DESC LIMIT 200');
  const contact = await db.all('SELECT * FROM contact ORDER BY id DESC LIMIT 200');
  res.json({ onboarding: onboard, contact: contact });
});

app.listen(port, ()=> console.log(`Server running on http://localhost:${port}`));
