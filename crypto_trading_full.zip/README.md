Crypto Trading Full Project (Demo)
=================================
This archive contains a minimal full-stack demo for a crypto trading onboarding site.
**Important:** This is a demo. Do NOT use this for real money without proper security,
legal review, and broker integrations.

Local run (server):
  cd server
  npm install
  npm run dev
Local run (frontend):
  cd frontend
  npm install
  npm run dev

Docker (build & up):
  docker-compose up --build

SendGrid:
  - Set SENDGRID_API_KEY, FROM_EMAIL, ADMIN_EMAIL in server/.env.example (copy to .env)
  - Server will attempt to send email notifications when configured.
