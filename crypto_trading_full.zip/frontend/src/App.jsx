import React, { useState } from 'react'
import axios from 'axios'
const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:4000'
export default function App(){
  const [contact, setContact] = useState({name:'', email:'', message:''})
  const [onboard, setOnboard] = useState({name:'', broker:'', amount:''})
  const [loadingContact, setLoadingContact] = useState(false)
  const [loadingOnboard, setLoadingOnboard] = useState(false)
  async function submitContact(e){
    e.preventDefault()
    setLoadingContact(true)
    try{
      await axios.post(`${API_BASE}/api/contact`, contact)
      alert('Message sent — we will reach out shortly (demo).')
      setContact({name:'', email:'', message:''})
    }catch(err){
      alert(err?.response?.data?.error || 'Error sending message')
    }finally{setLoadingContact(false)}
  }
  async function submitOnboard(e){
    e.preventDefault()
    if(!onboard.name || !onboard.amount){
      alert('Please enter name and pilot amount')
      return
    }
    setLoadingOnboard(true)
    try{
      await axios.post(`${API_BASE}/api/onboard`, {...onboard, agree:true})
      alert('Onboarding request received — we will contact you (demo).')
      setOnboard({name:'', broker:'', amount:''})
    }catch(err){
      alert(err?.response?.data?.error || 'Error requesting onboarding')
    }finally{setLoadingOnboard(false)}
  }
  return (
    <div className="container">
      <header className="header">
        <div className="logo">
          <div className="badge">CT</div>
          <div>
            <div style={{fontWeight:700}}>CrypTrade</div>
            <div className="small">Managed Crypto Trading</div>
          </div>
        </div>
        <div>
          <button className="btn" onClick={()=>{document.getElementById('onboard').scrollIntoView({behavior:'smooth'})}}>Start Pilot</button>
        </div>
      </header>
      <main className="hero">
        <section>
          <div className="card">
            <h1 style={{fontSize:26, margin:0}}>Crypto trading, managed transparently</h1>
            <p className="small">Pilot-first approach. Funds stay in your custody. Trade access only. Weekly reports & broker confirmations.</p>
            <div style={{marginTop:14}} className="kv">
              <div className="item">
                <div className="small">Pilot</div>
                <div style={{fontSize:18,fontWeight:700}}>$5,000</div>
              </div>
              <div className="item">
                <div className="small">Target</div>
                <div style={{fontSize:18,fontWeight:700}}>Consistent Growth</div>
              </div>
            </div>
            <div style={{marginTop:16}}>
              <h3 style={{marginTop:0}}>How it works</h3>
              <ol className="small">
                <li>Open a broker account in your name (we help).</li>
                <li>Fund a pilot allocation.</li>
                <li>We trade with trade-only access; you verify via broker confirmations.</li>
              </ol>
            </div>
          </div>
          <div style={{marginTop:14}} className="card">
            <h3 style={{marginTop:0}}>Strategy summary</h3>
            <ul className="small">
              <li>Assets: BTC, ETH, top liquid alts</li>
              <li>Approach: Rules-based signals + discretionary risk checks</li>
              <li>Risk controls: Max position, daily loss, portfolio drawdown cap</li>
              <li>Reporting: T+1 trade confirmations and monthly P&L</li>
            </ul>
          </div>
        </section>
        <aside>
          <div className="card">
            <h4 style={{marginTop:0}}>Contact & Onboarding</h4>
            <form onSubmit={submitContact}>
              <input className="input" placeholder="Your name" value={contact.name} onChange={e=>setContact({...contact,name:e.target.value})} />
              <div style={{height:8}} />
              <input className="input" placeholder="Email" value={contact.email} onChange={e=>setContact({...contact,email:e.target.value})} />
              <div style={{height:8}} />
              <textarea className="input" placeholder="Message (tell us about your goals)" value={contact.message} onChange={e=>setContact({...contact,message:e.target.value})} />
              <div style={{height:8}} />
              <button className="btn" type="submit">{loadingContact? 'Sending...':'Send message'}</button>
            </form>
            <div style={{height:14}} />
            <div className="small">Or request onboarding quickly:</div>
            <form id="onboard" onSubmit={submitOnboard} style={{marginTop:8}}>
              <input className="input" placeholder="Full name" value={onboard.name} onChange={e=>setOnboard({...onboard,name:e.target.value})} />
              <div style={{height:8}} />
              <input className="input" placeholder="Broker (optional)" value={onboard.broker} onChange={e=>setOnboard({...onboard,broker:e.target.value})} />
              <div style={{height:8}} />
              <input className="input" placeholder="Pilot amount (USD)" value={onboard.amount} onChange={e=>setOnboard({...onboard,amount:e.target.value})} />
              <div style={{height:8}} />
              <div style={{display:'flex',gap:8,alignItems:'center'}}>
                <input type="checkbox" id="agree" required style={{width:18,height:18}} />
                <label className="small">I understand the risks and confirm funds will remain in my broker custody.</label>
              </div>
              <div style={{height:8}} />
              <button className="btn" type="submit">{loadingOnboard? 'Submitting...':'Request Onboarding'}</button>
            </form>
          </div>
          <div style={{marginTop:12}} className="card">
            <h4 style={{marginTop:0}}>Fees</h4>
            <div className="small">Management fee: 1% / month<br/>Performance fee: 15% net profits (high-water mark)</div>
          </div>
        </aside>
      </main>
      <footer className="footer">© {new Date().getFullYear()} CrypTrade — Demo site. Not investment advice.</footer>
    </div>
  )
}
