# Crypto Trading Platform (Paper Trading Demo)

This is a **demo crypto trading platform** with frontend + backend.

- **Backend (server/)**: Express + SQLite (orders, fills, positions, CoinGecko market prices, paper trading engine)
- **Frontend (frontend/)**: React + Vite (Home, Onboarding, Market, Trading, Dashboard)
- **Docker**: `docker-compose.yml` included for local full-stack run

⚠️ Note: This is a **demo only**. Do not use with real client funds until security, compliance, and broker integrations are properly implemented.

---

## 🚀 Deployment Guide (GitHub + Render)

### 1. Upload to GitHub
1. Create a new repository on GitHub (e.g., `crypto-trading-platform`).
2. Unzip this project and push it to GitHub:
   ```bash
   git init
   git add .
   git commit -m "Initial demo commit"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<repo>.git
   git push -u origin main
   ```

### 2. Backend on Render (Web Service)
- New → Web Service → connect GitHub repo
- Root Directory: `server`
- Environment: Node
- Build Command: `npm install`
- Start Command: `npm start`
- Add environment variables:
  - `PORT=10000`
  - `ADMIN_SECRET=<choose-random-secret>`
  - `SENDGRID_API_KEY=<your-key>` (optional)
  - `FROM_EMAIL=you@domain.com` (if using SendGrid)
  - `ADMIN_EMAIL=admin@domain.com`
- Enable persistent disk if using SQLite.

### 3. Frontend on Render (Static Site)
- New → Static Site → connect GitHub repo
- Root Directory: `frontend`
- Build Command: `npm install && npm run build`
- Publish Directory: `dist`
- Environment Variable:  
  `VITE_API_URL=https://<your-backend-render-url>`

### 4. Test the App
- Frontend URL will be provided by Render (visit in browser).  
- Place trades from `/Trade` → view positions in `/Dashboard`.

### 5. Admin Endpoint
Protected with `ADMIN_SECRET`. Example:
```bash
curl -H "x-admin-secret: <ADMIN_SECRET>" https://<backend-url>/api/admin/requests
```

---

## 🛠 Local Development
1. Backend:
   ```bash
   cd server
   npm install
   npm run dev
   ```
   Runs on `http://localhost:4000`

2. Frontend:
   ```bash
   cd frontend
   npm install
   npm run dev
   ```
   Runs on `http://localhost:5173`

3. Create `frontend/.env`:
   ```
   VITE_API_URL=http://localhost:4000
   ```

---

## 📌 Notes
- This project currently uses **SQLite**. For production, switch to **Postgres** with `DATABASE_URL`.
- Render free tier is good for testing, but for uptime you need a paid plan.
- Do not onboard real investors without legal compliance (KYC/AML, licensing).

