const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();
const { open } = require('sqlite');
const axios = require('axios');
const sendgrid = require('@sendgrid/mail');

if (process.env.SENDGRID_API_KEY) {
  sendgrid.setApiKey(process.env.SENDGRID_API_KEY);
}

const app = express();
const port = process.env.PORT || 4000;
app.use(cors());
app.use(bodyParser.json());

let db;
(async () => {
  db = await open({ filename: path.join(__dirname,'data.db'), driver: sqlite3.Database });
  await db.run(`
    CREATE TABLE IF NOT EXISTS onboarding (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      broker TEXT,
      amount TEXT NOT NULL,
      createdAt TEXT NOT NULL
    );
  `);
  await db.run(`
    CREATE TABLE IF NOT EXISTS contact (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL,
      message TEXT,
      createdAt TEXT NOT NULL
    );
  `);
  await db.run(`
    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      client TEXT NOT NULL,
      symbol TEXT NOT NULL,
      side TEXT NOT NULL,
      type TEXT NOT NULL,
      price REAL,
      qty REAL NOT NULL,
      status TEXT NOT NULL,
      createdAt TEXT NOT NULL
    );
  `);
  await db.run(`
    CREATE TABLE IF NOT EXISTS fills (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      orderId INTEGER NOT NULL,
      price REAL NOT NULL,
      qty REAL NOT NULL,
      fee REAL DEFAULT 0,
      filledAt TEXT NOT NULL
    );
  `);
  await db.run(`
    CREATE TABLE IF NOT EXISTS positions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      client TEXT NOT NULL,
      symbol TEXT NOT NULL,
      qty REAL NOT NULL,
      avgPrice REAL NOT NULL,
      updatedAt TEXT NOT NULL
    );
  `);
  console.log('DB ready');
})();

app.get('/', (req, res) => {
  res.json({ status: 'server running' });
});

app.post('/api/onboard', async (req, res) => {
  const { name, broker, amount, agree } = req.body;
  if (!name || !amount || !agree) return res.status(400).json({ error: 'Missing required fields' });
  const createdAt = new Date().toISOString();
  const result = await db.run('INSERT INTO onboarding (name,broker,amount,createdAt) VALUES (?,?,?,?)', [name, broker || null, amount, createdAt]);
  const id = result.lastID;
  if (process.env.SENDGRID_API_KEY && process.env.ADMIN_EMAIL && process.env.FROM_EMAIL) {
    const msg = { to: process.env.ADMIN_EMAIL, from: process.env.FROM_EMAIL, subject: `New onboarding request #${id}`, text: `New onboarding request:\nName: ${name}\nBroker: ${broker || 'N/A'}\nAmount: ${amount}\nTime: ${createdAt}` };
    try { await sendgrid.send(msg); } catch(e){ console.error('SendGrid error', e); }
  }
  return res.json({ ok: true, id });
});

app.post('/api/contact', async (req, res) => {
  const { name, email, message } = req.body;
  if (!name || !email) return res.status(400).json({ error: 'Missing required fields' });
  const createdAt = new Date().toISOString();
  const result = await db.run('INSERT INTO contact (name,email,message,createdAt) VALUES (?,?,?,?)', [name, email, message || null, createdAt]);
  const id = result.lastID;
  if (process.env.SENDGRID_API_KEY && process.env.ADMIN_EMAIL && process.env.FROM_EMAIL) {
    const msg = { to: process.env.ADMIN_EMAIL, from: process.env.FROM_EMAIL, subject: `New contact message #${id}`, text: `From: ${name} <${email}>\nMessage:\n${message || ''}` };
    try { await sendgrid.send(msg); } catch(e){ console.error('SendGrid error', e); }
  }
  return res.json({ ok: true, id });
});

app.get('/api/markets', async (req, res) => {
  const symbols = (req.query.symbols || 'bitcoin,ethereum').split(',');
  try {
    const resp = await axios.get('https://api.coingecko.com/api/v3/simple/price', { params: { ids: symbols.join(','), vs_currencies: 'usd', include_24hr_change: true } });
    return res.json(resp.data);
  } catch (e) {
    console.error('CoinGecko error', e?.message);
    return res.status(500).json({ error: 'Market feed error' });
  }
});

app.post('/api/order', async (req, res) => {
  const { client, symbol, side, type, price, qty } = req.body;
  if (!client || !symbol || !side || !type || !qty) return res.status(400).json({ error: 'Missing fields' });
  const createdAt = new Date().toISOString();
  const result = await db.run('INSERT INTO orders (client,symbol,side,type,price,qty,status,createdAt) VALUES (?,?,?,?,?,?,?,?)', [client, symbol, side, type, price || null, qty, 'pending', createdAt]);
  const orderId = result.lastID;
  if (type === 'market') {
    try {
      const coinId = symbol.toLowerCase();
      const { data } = await axios.get('https://api.coingecko.com/api/v3/simple/price', { params: { ids: coinId, vs_currencies: 'usd' } });
      const lastPrice = data[coinId].usd;
      const filledAt = new Date().toISOString();
      const fee = 0;
      await db.run('INSERT INTO fills (orderId,price,qty,fee,filledAt) VALUES (?,?,?,?,?)', [orderId, lastPrice, qty, fee, filledAt]);
      await db.run('UPDATE orders SET status = ? WHERE id = ?', ['filled', orderId]);
      const pos = await db.get('SELECT * FROM positions WHERE client = ? AND symbol = ?', [client, symbol]);
      if (!pos) {
        await db.run('INSERT INTO positions (client,symbol,qty,avgPrice,updatedAt) VALUES (?,?,?,?,?)', [client, symbol, (side === 'buy' ? qty : -qty), lastPrice, filledAt]);
      } else {
        let newQty = pos.qty + (side === 'buy' ? qty : -qty);
        let newAvg = pos.avgPrice;
        if (side === 'buy') {
          newAvg = ((pos.avgPrice * pos.qty) + (lastPrice * qty)) / (pos.qty + qty);
        }
        if (newQty === 0) newAvg = 0;
        await db.run('UPDATE positions SET qty = ?, avgPrice = ?, updatedAt = ? WHERE id = ?', [newQty, newAvg, filledAt, pos.id]);
      }
    } catch (e) {
      console.error('Order fill error', e.message);
    }
  }
  return res.json({ ok: true, orderId });
});

app.get('/api/orders', async (req, res) => {
  const client = req.query.client;
  const rows = client ? await db.all('SELECT * FROM orders WHERE client = ? ORDER BY id DESC', [client]) : await db.all('SELECT * FROM orders ORDER BY id DESC');
  return res.json(rows);
});

app.get('/api/positions', async (req, res) => {
  const client = req.query.client;
  const rows = client ? await db.all('SELECT * FROM positions WHERE client = ?', [client]) : await db.all('SELECT * FROM positions');
  return res.json(rows);
});

app.get('/api/fills', async (req, res) => {
  const orderId = req.query.orderId;
  const rows = orderId ? await db.all('SELECT * FROM fills WHERE orderId = ?', [orderId]) : await db.all('SELECT * FROM fills ORDER BY id DESC LIMIT 200');
  return res.json(rows);
});

app.get('/api/admin/requests', async (req, res) => {
  const secret = req.headers['x-admin-secret'] || req.query.secret;
  if (process.env.ADMIN_SECRET && secret !== process.env.ADMIN_SECRET) return res.status(401).json({ error: 'Unauthorized' });
  const onboard = await db.all('SELECT * FROM onboarding ORDER BY id DESC LIMIT 200');
  const contact = await db.all('SELECT * FROM contact ORDER BY id DESC LIMIT 200');
  const orders = await db.all('SELECT * FROM orders ORDER BY id DESC LIMIT 200');
  const fills = await db.all('SELECT * FROM fills ORDER BY id DESC LIMIT 200');
  res.json({ onboarding: onboard, contact: contact, orders, fills });
});

setInterval(async () => {
  try {
    const pending = await db.all('SELECT * FROM orders WHERE status = ?', ['pending']);
    if (pending.length === 0) return;
    const symbols = [...new Set(pending.map(p => p.symbol.toLowerCase()))];
    const { data } = await axios.get('https://api.coingecko.com/api/v3/simple/price', { params: { ids: symbols.join(','), vs_currencies: 'usd' } });
    const now = new Date().toISOString();
    for (const order of pending) {
      const coin = order.symbol.toLowerCase();
      const last = data[coin] && data[coin].usd;
      if (!last) continue;
      if (order.type === 'limit') {
        if ((order.side === 'buy' && last <= order.price) || (order.side === 'sell' && last >= order.price)) {
          const fee = 0;
          await db.run('INSERT INTO fills (orderId,price,qty,fee,filledAt) VALUES (?,?,?,?,?)', [order.id, last, order.qty, fee, now]);
          await db.run('UPDATE orders SET status = ? WHERE id = ?', ['filled', order.id]);
          const pos = await db.get('SELECT * FROM positions WHERE client = ? AND symbol = ?', [order.client, order.symbol]);
          if (!pos) {
            await db.run('INSERT INTO positions (client,symbol,qty,avgPrice,updatedAt) VALUES (?,?,?,?,?)', [order.client, order.symbol, (order.side === 'buy' ? order.qty : -order.qty), last, now]);
          } else {
            let newQty = pos.qty + (order.side === 'buy' ? order.qty : -order.qty);
            let newAvg = pos.avgPrice;
            if (order.side === 'buy') {
              newAvg = ((pos.avgPrice * pos.qty) + (last * order.qty)) / (pos.qty + order.qty);
            }
            if (newQty === 0) newAvg = 0;
            await db.run('UPDATE positions SET qty = ?, avgPrice = ?, updatedAt = ? WHERE id = ?', [newQty, newAvg, now, pos.id]);
          }
        }
      }
    }
  } catch (e) {
    console.error('Background matching error', e.message);
  }
}, 10000);

app.listen(port, () => console.log(`Server running on http://localhost:${port}`));
