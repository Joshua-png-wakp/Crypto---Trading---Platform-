import React, {useEffect, useState} from 'react';
import axios from 'axios';
const API = import.meta.env.VITE_API_URL || 'http://localhost:4000';
export default function Dashboard({clientId='demo'}){
  const [positions,setPositions] = useState([]);
  const [orders,setOrders] = useState([]);
  async function fetchData(){ try{ const [pRes,oRes] = await Promise.all([axios.get(`${API}/api/positions`, { params: { client: clientId } }), axios.get(`${API}/api/orders`, { params: { client: clientId } })]); setPositions(pRes.data); setOrders(oRes.data); }catch(e){ console.error(e); } }
  useEffect(()=>{ fetchData(); const id=setInterval(fetchData,10000); return ()=>clearInterval(id); },[]);
  return (<div><h2>Dashboard</h2><div className="card"><h4>Positions</h4>{positions.length===0? <div>No positions</div> : positions.map(p => <div key={p.id}>{p.symbol.toUpperCase()} — Qty: {p.qty} — Avg: ${p.avgPrice}</div>)}</div><div className="card" style={{marginTop:12}}><h4>Recent Orders</h4>{orders.length===0? <div>No orders</div> : orders.map(o => <div key={o.id}>{o.symbol} {o.side} {o.qty} @ {o.price||'market'} — {o.status}</div>)}</div></div>);
}
