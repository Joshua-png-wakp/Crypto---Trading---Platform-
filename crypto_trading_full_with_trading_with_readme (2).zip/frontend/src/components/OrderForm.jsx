import React, {useState} from 'react';
import axios from 'axios';
const API = import.meta.env.VITE_API_URL || 'http://localhost:4000';
export default function OrderForm({clientId='demo'}) {
  const [symbol,setSymbol] = useState('bitcoin');
  const [side,setSide] = useState('buy');
  const [type,setType] = useState('market');
  const [price,setPrice] = useState('');
  const [qty,setQty] = useState('');
  async function submit(e){ e.preventDefault(); try{ await axios.post(`${API}/api/order`, { client: clientId, symbol, side, type, price: type==='limit'?parseFloat(price):null, qty: parseFloat(qty) }); alert('Order submitted (paper trading demo).'); setPrice(''); setQty(''); }catch(err){ alert(err?.response?.data?.error || 'Error placing order'); } }
  return (<div className="card"><h3>Place Order (Paper Demo)</h3><form onSubmit={submit}><div><label>Symbol</label><input value={symbol} onChange={e=>setSymbol(e.target.value)} className="input" /></div><div><label>Side</label><select value={side} onChange={e=>setSide(e.target.value)} className="input"><option value="buy">Buy</option><option value="sell">Sell</option></select></div><div><label>Type</label><select value={type} onChange={e=>setType(e.target.value)} className="input"><option value="market">Market</option><option value="limit">Limit</option></select></div>{type==='limit' && <div><label>Price (USD)</label><input value={price} onChange={e=>setPrice(e.target.value)} className="input" /></div>}<div><label>Qty</label><input value={qty} onChange={e=>setQty(e.target.value)} className="input" /></div><div style={{height:8}} /><button className="btn" type="submit">Place Order</button></form></div>);
}
