import React, {useEffect, useState} from 'react';
import axios from 'axios';
const API = import.meta.env.VITE_API_URL || 'http://localhost:4000';
export default function MarketList({symbols=['bitcoin','ethereum']}){
  const [prices,setPrices] = useState({});
  useEffect(()=>{
    let mounted = true;
    async function fetchPrices(){
      try{ const res = await axios.get(`${API}/api/markets`, { params: { symbols: symbols.join(',') } }); if(mounted) setPrices(res.data); }catch(e){ console.error(e); }
    }
    fetchPrices(); const id = setInterval(fetchPrices, 10000); return ()=>{ mounted=false; clearInterval(id); }
  },[symbols]);
  return (<div className="card"><h3>Live Market Prices</h3><ul>{symbols.map(s => (<li key={s}>{s.toUpperCase()}: ${prices[s]?.usd ?? '—'} {prices[s] && prices[s].usd_24h_change ? `(${prices[s].usd_24h_change.toFixed(2)}%)` : ''}</li>))}</ul></div>);
}
